bat v1.0
Created by bagzie
Licensing: OGA BY 3.0 (see LICENSE.txt)
Source: https://opengameart.org/node/26447
Reworked to 48x64 for Stendhal by Jordan Irwin (AntumDeluge)
