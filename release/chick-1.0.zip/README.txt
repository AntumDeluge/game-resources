chick v1.0
Edited by Jordan Irwin
Based on Chicken Sprites by Shepardskin: https://opengameart.org/content/chicken-sprites
Licensing: CC0 1.0 (see LICENSE.txt)

