### Mages Rework Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top;">
      ![Preview](preview.gif)
    </td>
  </tr>
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top;">
      ![Offset Preview](preview-offset.gif)
    </td>
  </tr>
</table>

[OpenGameArt.org submission](https://opengameart.org/node/76967)

By [Sollision](https://opengameart.org/user/30796):
- [Mage Sprites (Idle and Walking)](https://opengameart.org/node/52761) (CC0)
