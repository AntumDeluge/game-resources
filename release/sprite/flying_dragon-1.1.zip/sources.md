### Flying Dragon Rework Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/83655)

#### Source Assets:
---

By [ZaPaper](https://opengameart.org/users/zapaper):
- [Red Dragon](https://opengameart.org/node/79018) (CC BY 3.0)
