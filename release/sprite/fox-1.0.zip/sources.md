### Fox (Wolf Pack Rework) Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/88912)

#### Source Assets:
---

By [patvanmackelberg](https://opengameart.org/users/patvanmackelberg):
- [Wolf Pack! 32x32 Walking Wolf Animation](https://opengameart.org/node/48199) (CC0)

By [bleutailfly](https://stendhalgame.org/character/bleutailfly.html):
- [fox](https://postimg.cc/BXsC1Jx0) (CC BY-SA 3.0/4.0)
