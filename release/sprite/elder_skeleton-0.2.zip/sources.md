### Elder Skeleton Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/88266)

#### Source Assets:
---

By [artisticdude](https://opengameart.org/users/artisticdude):
- [Zombies & Skeletons](https://opengameart.org/node/6669) (CC0)

By [Stephen Challener (Redshrike)](https://opengameart.org/users/redshrike):
- [16x16, 16x24, 32x32 rpg enemies--updated](https://opengameart.org/node/6262) (OGA BY 3.0 / CC BY 3.0)
