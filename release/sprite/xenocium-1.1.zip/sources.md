### Xenocium Sprite Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/86934)

#### Source Assets:
---

By [Rexi Andriansyah (Rexes)](https://opengameart.org/users/rexes):
- [Tuyul](https://opengameart.org/node/75162) (OGA BY 3.0)
