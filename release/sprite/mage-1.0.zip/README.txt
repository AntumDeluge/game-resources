mage v1.0
Edited by Jordan Irwin (AntumDeluge)
Based on Mage Sprites by Sollision: https://opengameart.org/content/mage-sprites-idle-and-walking
Licensing: CC0 1.0 (see LICENSE.txt)
