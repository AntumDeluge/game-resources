Name:
  Horses Rework
Version:
  1.1
Description:
  Horse sprites based on "[LPC] Horses" by bluecarrot16, reworked for
  use in Stendhal.
Licensing:
  Included text:
    - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 (see: LICENSE.txt)
  According to the original author, this work can be distributed under the following licenses
  as well:
    - OpenGameArt.org Attribution (OGA BY) version 3.0
    - Creative Commons Attribution (CC BY) version 3.0
    - GNU General Public License (GPL) version 2.0 or 3.0
Attribution:
  "[LPC] Horses" Artist: bluecarrot16
  Reworked by Jordan Irwin (AntumDeluge)
Links:
  - OpenGameArt.org submissions: https://opengameart.org/node/77472
  - Original sprites by bluecarrot16: https://opengameart.org/node/69398
  - Stendhal: https://stendhalgame.org/
