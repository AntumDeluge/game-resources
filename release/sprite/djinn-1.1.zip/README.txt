Name:
  Djinn
Version:
  1.1
Description:
  Djinn sprite in Cabbit style created as drop-in replacement
  for Stendhal.
Sprite details:
  - Orientation: orthogonal
    - N/E/S/W format for Stendhal.
    - S/W/E/N format for RPG Maker & RPG Boss.
  - Dimensions: 24x32 & 48x64 (scaled)
  - Animation:
    - idle (center frames)
    - walking/floating: 12 frames (3 per direction)
    - Animated preview @ 150ms delay.
  - PNG images optimized with indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 or later (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 or later (see: LICENSE-CC-BY-[3.0|4.0].txt)
Copyright/Attribution:
  Created by Svetlana Kushnariova (Cabbit) <lana-chan@yandex.ru> & Jordan Irwin (AntumDeluge)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/82929
  - See also: sources.md
Notes:
  - IMPORTANT: As part of Cabbit's attribution requirements, please credit her as
    "Svetlana Kushnariova" & include her email address: lana-chan@yandex.ru
  - The 48x64 "scale" & "scale2x" versions will be replaced by cleaned up versions
    once finished.
