Name:
  Trolls
Version:
  1.1
Description:
  Troll sprites for Stendhal, based on Muscleman/Ogre/Minotaur by
  Tuomo Untinen (Reemax).
Details:
  - Orientation: orthogonal
    - N/E/S/W format for Stendhal.
    - S/W/E/N format for RPG Maker & RPG Boss.
  - Dimensions: 48x64
  - Animation:
    - idle (center frames)
    - walking: 12 frames (3 per direction)
    - Animated preview @ 150ms delay.
  - PNG images optimized with indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE.txt)
Copyright/Attribution:
  Original Muscleman/Ogre/Minotaur by Tuomo Untinen (Reemax), reworked
  by Jordan Irwin (AntumDeluge).
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/78138
  - See also: sources.md
