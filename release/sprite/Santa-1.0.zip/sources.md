### Santa Sprite Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
  </tr>
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/82411)

By [Svetlana Kushnariova (Cabbit)](https://opengameart.org/user/15048):
- [24x32 bases](https://opengameart.org/node/24944) (CC0)
- [24x32 characters, 16x16 tiles](https://opengameart.org/node/72969) (OGA BY 3.0 / CC BY 3.0)
