orc v1.0
Based on "Muscleman/Ogre/Minotaur" by Tuomo Untinen (Reemax): https://opengameart.org/node/24876
Reworked for Stendhal by Jordan Irwin (AntumDeluge)
Licensing: Creative Commons Attribution (CC BY) version 3.0
