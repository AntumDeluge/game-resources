Name:
  Space Bot Rework
Version:
  1.1
Description:
  Reworked versions of DoubleU Creativity's Space Bot.
Details:
  - Orientation: orthogonal
    - N/E/S/W format for Stendhal.
    - S/W/E/N format for RPG Maker & RPG Boss.
  - Dimensions: 48x64
  - Animation:
    - idle (any column of frames)
    - floating: 12 frames (3 per direction)
    - Animated preview @ 150ms delay.
  - PNG images optimized with indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE.txt)
Copyright/Attribution:
  Created by DoubleU Creativity. Reworked by Jordan Irwin (AntumDeluge).
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/78352
  - See also: sources.md
