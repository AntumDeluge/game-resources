dark_soldier v1.0
Created by Stephen Challener (Redshrike)
Source: https://opengameart.org/node/12858
Licensing: Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 (see: LICENSE.txt)

Changes from original:
- Reworked for Stendhal by Jordan Irwin (AntumDeluge) (attribution not required)
