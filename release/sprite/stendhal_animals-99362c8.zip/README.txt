Name:
  Stendhal Animals
Git revision:
  99362c8
Description:
  Animal sprites created for Stendhal.
Sprite details:
  - Dimensions:
    - 48x64: monkey & ram
    - 64x64: bull, cow, lion, & tiger
  - Orientation: N/S/E/W
  - Frames: 3 per direction
  - PNG images & GIMP source files (.xcf) use RGB color.
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 or later
  - Creative Commons Attribution (CC BY) version 3.0 or later
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 or later
  - GNU General Public License (GPL) version 2.0 or later
Attribution:
  Created by Kimmo Rundelin (kiheru)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81251
