Name:
  Oracles
Version:
  1.1
Description:
  A set of oracle sprites in Cabbit style created as drop-in replacements
  for Stendhal.
Sprite details:
  - Orientation: orthogonal
    - N/E/S/W
    - S/W/E/N
  - Dimensions: 48x64
  - Animation:
    - idle (any column set of frames)
    - moving/floating: 12 frames (3 per direction)
    - Animated preview @ 150ms delay.
  - PNG images optimized with indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 (see: LICENSE.txt)
Copyright/Attribution:
  Created by Svetlana Kushnariova (Cabbit) <lana-chan@yandex.ru>, Nila122,
  olonu, leangoro, & Jordan Irwin (AntumDeluge)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/83626
  - See also: sources.md
Notes:
  - IMPORTANT: As part of Cabbit's attribution requirements, please credit her
    as "Svetlana Kushnariova" & include her email address: lana-chan@yandex.ru
  - The hair used in this work is created by Nila122 & licensed under
    CC BY-SA 3.0. If you replace the hair, attribution to Nila122 is not
    required & the work can be re-distributed under OGA BY version 3.0 or later,
    or CC BY version 3.0 or later.
  - It is not required to attribute the following authors for this work. However,
    their names are listed in the "Copyright/Attribution" section for anyone that
    would like to give credit:
      - leangoro
