minotaur v1.2
Created by Jordan Irwin (AntumDeluge)
Licensing:
- OpenGameArt.org Attribution (OGA BY) version 3.0 or later (see LICENSE.txt).
- Only license text for OGA BY 3.0 is included with this release, but it may
  also be released under Creative Commons Attribution (CC BY) version 3.0 or
  later.
Links:
- OpenGameArt.org page: https://opengameart.org/node/76913
