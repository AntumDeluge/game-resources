cat v1.0
Source: "[LPC] Cats and Dogs" by bluecarrot16: https://opengameart.org/node/69399
Reworked for Stendhal by Jordan Irwin (AntumDeluge)
Licensing:
  Only license text for Creative Commons Attribution-ShareAlike (CC BY-SA) version
  3.0 is included with this release (see: LICENSE.txt). But this work may also be
  released/redistributed under Creative Commons Attribution (CC BY) version 3.0,
  GNU General Public License (GPL) version 2.0 or version 3.0, or OpenGameArt
  Attribution (OGA BY) version 3.0 according to the original author.
