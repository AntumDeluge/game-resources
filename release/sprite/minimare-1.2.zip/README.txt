Name:
  Minimare Rework
Version:
  1.2
Description:
  Rework of Kevin Smith's minimare sprite for use as drop-in
  replacements for dark aruthon & robot aruthon enemies in
  Stendhal.
Details:
  - Orientation: orthogonal (N/E/S/W)
  - Dimensions: 24x32, 32x32, & 48x64 (scale2x filter)
  - Animation:
    - idle (center frames)
    - walking: 12 frames (3 per direction)
    - Animated preview @ 150ms delay.
  - PNG images use indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE.txt)
Copyright/Attribution:
  Created by Kevin Smith (TKZ Productions) & Jordan Irwin (AntumDeluge)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/82760
  - See also: sources.md
