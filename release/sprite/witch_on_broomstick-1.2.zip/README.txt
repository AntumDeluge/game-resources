Name:
  Witch on Broomstick
Version:
  1.2
Description:
  Witch sprites created as drop-in replacements for Stendhal.
  Based on work by Svetlana Kushnariova.
Sprite details:
  - Orientation: orthogonal
    - N/E/S/W format for Stendhal.
    - S/W/E/N format for RPG Maker & RPG Boss.
  - Dimensions: 24x32 & 48x64
  - Animation:
    - idle (center frames)
    - walking: 12 frames (3 per direction)
    - Animated preview @ 150ms delay.
  - PNG images optimized with indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 or later (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 or later (see: LICENSE-CC-BY-[3.0|4.0].txt)
Copyright/Attribution:
  Created by Svetlana Kushnariova (Cabbit) <lana-chan@yandex.ru> & Jordan Irwin (AntumDeluge)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/86131
  - See also: sources.md
