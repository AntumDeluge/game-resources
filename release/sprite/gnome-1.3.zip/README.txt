gnome v1.3
Original "Green Cap Character 16x18" by isaiah658: https://opengameart.org/node/66252
Reworked for Stendhal by Jordan Irwin (AntumDeluge)
Licensing: Creative Commons Zero (CC0) version 1.0 (see: LICENSE.txt)
