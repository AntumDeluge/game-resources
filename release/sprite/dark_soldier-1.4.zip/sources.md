### Dark Soldier Rework Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/77901)

#### Source Assets:
---

By [johnny_automatic](https://openclipart.org/user-detail/johnny_automatic):
- [reclining devil](https://openclipart.org/detail/4365) (CC0)

By [Stephen Challener (Redshrike)](https://opengameart.org/users/redshrike) & [Bertram](https://opengameart.org/users/bertram):
- [Dark Soldier for Valyria Tear](https://opengameart.org/node/12858) (CC BY-SA 3.0)
