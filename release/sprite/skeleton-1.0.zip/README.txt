Name:
  Skeletons Rework
Version:
  1.0
Description:
  Animated & reworked versions of artisticdude's skeleton sprite.
  Created as a drop-in replacement for Stendhal.
Details:
  - Orientation: orthogonal
    - N/E/S/W format for Stendhal.
    - Will add S/W/E/N format for RPG Maker & RPGBoss.
  - Dimensions: 24x32 (will be adding more sizes later)
  - Animation:
    - idle (center frames)
    - walking: 12 frames (3 per direction)
    - Animated preview @ 150ms delay.
  - PNG images use indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - Creative Commons Zero (CC0) (see: LICENSE.txt)
Attribution:
  Created by artisticdude & Jordan Irwin (AntumDeluge)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/83067
  - See also: sources.md
Notes:
  - Attributions for this work are not required. However, the names
    of the authors have been listed in the "Attribution" section for
    anyone that would like to give credit.
