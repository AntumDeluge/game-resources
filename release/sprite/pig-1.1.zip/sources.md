### Pigs Rework Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/83210)

#### Source Assets:
---

By [Daniel Eddeland (daneeklu)](https://opengameart.org/users/daneeklu):
- [LPC style farm animals](https://opengameart.org/node/11629) (CC BY 3.0 / GPL 2.0)
