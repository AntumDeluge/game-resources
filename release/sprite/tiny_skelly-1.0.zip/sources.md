### Tiny Skelly Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/82734)

By [Stephen Challener (Redshrike)](https://opengameart.org/users/Redshrike):
- [16x16, 16x24, 32x32 rpg enemies--updated](https://opengameart.org/node/6262) (OGA BY 3.0)
