Name:
  Tiny Skelly (RPG Enemies Rework)
Version:
  1.0
Description:
  Stephen Challener's skeleton sprite reworked for use in Stendhal.
Details:
  - Orientation: orthogonal (N/E/S/W)
  - Dimensions: 16x18, 16x32, 24x32, 32x32, & 48x64 (scale2x filter)
  - Animation:
    - idle (center frames)
    - walking: 12 frames (3 per direction)
  - PNG images use indexed color (smaller files).
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE-CC-BY-3.0.txt)
Copyright/Attribution:
  Stephen Challener (Redshrike), hosted by OpenGameArt.org
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/82734
  - See also: sources.md
Notes:
  - You do not need to credit me. I have only made some position &
    sizing adjustments.
  - IMPORTANT: As part of Stephen Challener's attribution requirements,
    please include a link back to OpenGameArt.org in your credits.
