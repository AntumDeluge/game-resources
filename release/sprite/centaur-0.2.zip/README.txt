Name:
  centaur
Version:
  0.2
Description:
  Centaur sprite created for Stendhal by Jordan Irwin (AntumDeluge).
  Based on "[LPC] Horses" by bluecarrot16 & "24x32 bases" by
  Svetlana Kushnariova (Cabbit).
Licensing:
  Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0
  (see: LICENSE.txt)
Attribution:
  bluecarrot16
  Svetlana Kushnariova (Cabbit) (not required/CC0)
  Jordan Irwin (AntumDeluge)
Links:
  - OpenGameArt.org page: https://opengameart.org/node/79289
  - [LPC] Horses: https://opengameart.org/node/69398
  - 24x32 bases: https://opengameart.org/node/24944
  - Stendhal: https://stendhalgame.org/
