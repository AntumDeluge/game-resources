Name:
  Lederhosen Outfit
Version:
  1.0
Description:
  A lederhosen outfit sprite originally created for Stendhal
  (https://stendhalgame.org/). Compatible with Charas sprites
  (http://charas-project.net/). Currently reworking for use
  with Svetlana Kushnariova's (Cabbit) sprites
  (https://opengameart.org/user/15048).
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE-CC-BY-3.0.txt)
Attribution:
  Created by Jordan Irwin (AntumDeluge)
Links:
- OpenGameArt.org page: https://opengameart.org/node/80172
- Stendhal: https://stendhalgame.org/
