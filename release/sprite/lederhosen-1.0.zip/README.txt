Name:
  Lederhosen Outfit
Version:
  1.0
Description:
  A lederhosen outfit originally created for Stendhal. Compatible with Charas or
  Cabbit's style sprites (currently only 48x64 available).
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 or later (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 or later (see: LICENSE-CC-BY-3.0.txt)
Links:
  - OpenGameArt.org submission: https://opengameart.org/node/80172
  - Stendhal: https://stendhalgame.org/
  - Cabbit's original base sprites: https://opengameart.org/node/24944
  - Additional bases by diamonddmgirl: https://opengameart.org/node/67861
  - Charas Project: http://charas-project.net/
