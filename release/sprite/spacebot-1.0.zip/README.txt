spacebot v1.0
Description: Reworked versions of DoubleU Creativity's Space Bot: https://opengameart.org/node/52537.
Reworked for Stendhal by Jordan Irwin (AntumDeluge)
Licensing: Creative Commons Attribution (CC BY) version 3.0
