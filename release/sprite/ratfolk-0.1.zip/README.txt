Name:
  Ratfolk
Version:
  0.1
Description:
  Ratfolk sprites created for Stendhal. The body is a modified
  Cabbit base. The head is based on Redhrike's rat king.
Details:
  - Orientation: orthogonal (N/E/S/W)
  - Dimensions: 24x32, 32x48 (rat_king only), & 48x64 (scale2x filter)
  - Animation:
    - idle (center frames)
    - walking: 12 frames (3 per direction)
  - PNG images use indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE.txt)
Copyright/Attribution:
  Created by Svetlana Kushnariova (Cabbit), Stephen Challener (Redshrike), & Jordan Irwin (AntumDeluge)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/82451
  - See also: sources.md
Notes:
  - A scaled version of Redshrike's rat_king is included.
  - IMPORTANT:
    - Up to this point, included works by Cabbit do not require attribution.
      Her bases are licensed under CC0. But, Svetlana kushnariova is included
      in the Copyright/Attribution section for any that would like to credit
      her.
