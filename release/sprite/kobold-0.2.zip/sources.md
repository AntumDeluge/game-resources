### Kobold Sprite Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top;">
      ![Static Preview](preview.png)
    </td>
    <td style="border: 0px; vertical-align: top;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/81952)

By [yolkati](https://opengameart.org/user/1404):
- [Dog soldier](https://opengameart.org/node/15636) (CC BY-SA 3.0)

By [Svetlana Kushnariova (Cabbit)](https://opengameart.org/user/15048):
- [24x32 bases](https://opengameart.org/node/24944) (CC0)
