Name:
  Kobolds (Dog Soldier Rework)
Version:
  0.2
Description:
  yolkati's Dog Soldier reworked as a kobold sprite drop-in replacement
  for Stendhal.
Sprite details:
  - Dimensions: 24x32 & 48x64
  - Orientation: orthogonal (N/S/E/W)
  - Animation:
    - idle (center frame)
    - walking: 12 frames (3 per direction)
  - PNG images use indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 (see: LICENSE.txt)
Copyright/Attribution:
  Created by yokati, Svetlana Kushnariova (Cabbit), & Jordan Irwin (AntumDeluge)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81952
  - See also: sources.md
Notes:
  - yokati's original sprite is included (48x48) with transparent background &
    converted to indexed color.
  - IMPORTANT:
    - Cabbit's bases are licensed under CC0. She does not require attribution
      for their use. However, she is listed here in the "Copyright/Attribution"
      section for anyone that would like to credit her.
