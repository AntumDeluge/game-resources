Name:
  Dark Soldier Rework
Version:
  1.3
Description:
  Reworked versions of "Dark Soldier for Valyria Tear" by Stephen Challener (Redshrike)
  for Stendhal.
Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 (see: LICENSE.txt)
Attribution:
  Created by Stephen Challener (Redshrike)
  Reworked for Stendhal by Jordan Irwin (AntumDeluge)
Links:
  - OpenGameArt.org submission: https://opengameart.org/node/77901
  - Original by Stephen Challener: https://opengameart.org/node/12858
