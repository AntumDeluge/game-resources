blob v1.0
Created by Jordan Irwin (AntumDeluge)
Licensing: CC0 1.0 (see LICENSE.txt)

