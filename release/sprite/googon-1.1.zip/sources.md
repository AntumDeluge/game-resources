### Googon Sprite Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/84678)

#### Source Assets:
---

By [Tracy](https://opengameart.org/users/tracy):
- [NPC one eyed Monster](https://opengameart.org/node/13716) (CC BY 3.0)
