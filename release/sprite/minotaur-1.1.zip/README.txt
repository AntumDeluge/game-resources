minotaur v1.1
Created by Jordan Irwin (AntumDeluge)
Licensing: Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE.txt)
OpenGameArt page: https://opengameart.org/node/76913
