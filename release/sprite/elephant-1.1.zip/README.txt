Name:
  Elephant Rework
Version:
  1.1
Description:
  Elephant sprite created for Stendhal. Based on lawnjelly's
  elephant.
Sprite details:
  - Orientation: orthogonal
    - N/E/S/W format for Stendhal.
    - S/W/E/N format for RPG Maker & RPG Boss.
  - Dimensions: 96x96
  - Animation:
    - idle (center frames)
    - walking: 12 frames (3 per direction)
    - Animated preview @ 150ms delay.
  - PNG images & GIMP sources (.xcf) use RGB color.
Licensing:
  - Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE.txt)
Copyright/Attribution:
  Created by lawnjelly & Jordan Irwin (AntumDeluge)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/84509
  - See also: sources.md
