### Beaver Sprite Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


Created by [bleutailfly](https://stendhalgame.org/character/bleutailfly.html) (CC BY-SA 3.0):
- [initial Git commit](https://github.com/arianne/stendhal/blob/1024e8427d1eeddc49b30644c0641079cd65f1bc/data/sprites/monsters/farm_animal/beaver.png)
- [current Git commit](https://github.com/arianne/stendhal/blob/master/data/sprites/monsters/farm_animal/beaver.png)

[OpenGameArt.org submission](https://opengameart.org/node/97131)
