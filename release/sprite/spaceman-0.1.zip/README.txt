spaceman v0.1
Description: Reworked versions of "Space Bot" by DoubleU Creativity: https://opengameart.org/node/52537.
Reworked by Jordan Irwin (AntumDeluge)
Licensing: Creative Commons Attribution (CC BY) version 3.0
