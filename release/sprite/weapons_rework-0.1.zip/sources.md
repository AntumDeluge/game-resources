### Weapons Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top;">
      ![Static Preview](preview-battleaxe.png)
    </td>
  </tr>
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top;">
      ![Animated Preview](preview-battleaxe.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/82261)

By [GrumpyDiamond](https://opengameart.org/user/32684):
- [Pixel Weapons1](https://opengameart.org/node/54590) (CC0)
