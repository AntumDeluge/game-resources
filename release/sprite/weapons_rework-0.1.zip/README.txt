Name:
  Battle Axe/Weapons Rework
Version:
  0.1
Description:
  GrumpyDiamond's axe scaled down & reworked into a sprite sheet for
  animating.
Details:
  - Dimensions: 14x14 & 16x16
  - Animation: 8 frames (animated preview at 100ms delay)
  - PNG images use indexed color (smaller files).
Licensing:
  - Creative Commons Zero (CC0) (see: LICENSE.txt)
Attribution:
  Created by GrumpyDiamond & Jordan Irwin (AntumDeluge)
Links:
  - OpenGameArt.org submission: https://opengameart.org/node/82261
  - See also: sources.md
Notes:
  - The authors of this work do not require attribution. But their names
    are listed in the "Attribution" section for anyone that would like to
    credit them.
