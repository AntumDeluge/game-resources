### Orcs Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview-alt1.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/77703)

#### Source Assets:
---

By [Angry Amish](https://opengameart.org/users/Angry-Amish):
- [Skull](https://opengameart.org/node/79522) (CC0)

By [Tuomo Untinen (Reemax)](https://opengameart.org/users/Reemax):
- [Muscleman/Ogre/Minotaur](https://opengameart.org/node/24876) (CC BY 3.0)
