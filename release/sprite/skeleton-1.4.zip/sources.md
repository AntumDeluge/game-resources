### Skeletons Rework Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/83067)

#### Source Assets:
---

By [artisticdude](https://opengameart.org/users/artisticdude):
- [Zombies & Skeletons](https://opengameart.org/node/6669) (CC0)

By [LordNeo](https://opengameart.org/users/LordNeo):
- [round shield [64x64]](https://opengameart.org/node/10893) (CC0)
