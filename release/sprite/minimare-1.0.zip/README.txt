Name:
  Minimare Rework
Version:
  1.0
Description:
  Small rework of Kevin Smith's minimare sprite for use as drop-in
  replacement for the dark aruthon creature in Stendhal.
Details:
  - Orientation: orthogonal (N/E/S/W)
  - Dimensions: 24x32, 32x32, & 48x64 (scale2x filter)
  - Animation:
    - idle (center frames)
    - walking: 12 frames (3 per direction)
    - Animated preview @ 150ms delay.
  - PNG images use indexed color (smaller files).
Licensing:
  - Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE.txt)
Copyright/Attribution:
  Created by Kevin Smith (TKZ Productions)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/82760
  - See also: sources.md
Notes:
  - Attribution is only required for Kevin Smith (TKZ Productions).
    Any changes/adjustments I have made can be considered CC0.
  - Attribution requirements may change with future revisions.
