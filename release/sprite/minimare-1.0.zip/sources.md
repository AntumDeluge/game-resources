### Brain Monster Sprite Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/82760)

By [Kevin Smith (TKZ Productions)](https://opengameart.org/users/TKZ-Productions):
- [A Lonely Nightmare - Minimare (Monster)](https://opengameart.org/node/50703) (CC BY 3.0)
