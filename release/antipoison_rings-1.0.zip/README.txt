antipoison_rings v1.0
Created by Jordan Irwin (AntumDeluge)
Licensing: CC BY 3.0 (see LICENSE.txt)

