minotaur v0.3
Created by Jordan Irwin
Licensing: CC BY 3.0 (see LICENSE.txt)
