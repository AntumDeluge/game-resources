minotaur v0.2
Created by Jordan Irwin
Licensing: CC BY 3.0 (see LICENSE.txt)

