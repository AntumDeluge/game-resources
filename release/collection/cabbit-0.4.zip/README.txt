Name:
  Cabbit Collection
Version:
  0.4
Description:
  A collection of sprites created by or based on the work of Svetlana Kushnariova (Cabbit).
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 or later (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 or later (see: LICENSE-CC-BY-3.0.txt)
Attribution:
  Svetlana Kushnariova (Cabbit)
  diamonddmgirl
  Jordan Irwin (AntumDeluge)
Links:
  - OpenGameArt.org page: https://opengameart.org/node/79804
  - For links to Cabbit's & diamonddmgirl's submissions, see "sources.md" file.
