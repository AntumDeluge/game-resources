### Statues Collection Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top;">
      ![Bust](preview.png)
    </td>
    <td style="border: 0px;">
      ![Attribution](attribution.png)
    </td>
  </tr>
</table>

[OpenGameArt.org submission](https://opengameart.org/node/81798)

By [Daniel Cook](https://plus.google.com/+DanielCookGameDesign), [Jetrel](https://opengameart.org/user/402), [Zachariah Husiar (Zabin)](https://opengameart.org/user/3356), & [Bertram](https://opengameart.org/user/665):
- stone armor from [2d Lost Garden Zelda style tiles resized to 32x32 with additions](https://opengameart.org/node/11758) (CC BY 3.0)

By [Hyptosis](https://opengameart.org/user/2937):
- bust & fountain from [Mage City Arcanos](https://opengameart.org/node/11192) (CC0)

By [Hyptosis](https://opengameart.org/user/2937) & [mold](https://opengameart.org/user/12427):
- child praying (CC0)
