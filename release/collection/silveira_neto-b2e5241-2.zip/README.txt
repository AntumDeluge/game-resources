Name:
  OpenPixels Collection
Version:
  b2e5241-2
Description:
  Sprites & tilesets created by Silveira Neto for OpenPixels project.
Licensing:
  Creative Commons Attribution-ShareAlike (CC BY-SA) version 4.0
  (see: LICENSE.txt)
Attribution:
  Created by Silveira Neto
Links:
  - Silveira Neto’s blog: http://silveiraneto.net/
  - OpenPixels GitHub: https://github.com/silveira/openpixels
  - OpenGameArt.org page: https://opengameart.org/node/79342
