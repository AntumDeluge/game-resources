Silveira Neto collection (CC BY-SA 3.0):
- [OpenPixels Project](https://github.com/silveira/openpixels)
- [Blog](http://silveiraneto.net/2009/07/31/my-free-tileset-version-10) (outdated)
