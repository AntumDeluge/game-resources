cabbit-bases v0.1
Description:
    Sprite bases created by, or based on work by, Svetlana Kushnariova (Cabbit)
    & diamonddmgirl.
Licensing: Creative Commons Zero (CC0) version 1.0 (see: LICENSE.txt)
Sources:
  - https://opengameart.org/node/24944 (original sprites by Cabbit)
  - https://opengameart.org/node/67861 (additional sprites by diamonddmgirl)
OpenGameArt.org page: https://opengameart.org/node/79237 (additional sprites by Jordan Irwin (AntumDeluge))
