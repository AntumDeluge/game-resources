Name:
  Statues & Fountains Collection
Version:
  0.1
Description:
  A collection of statues & fountains tilesets for potential use
  as drop-in replacements or new additions in Stendhal.
Tilesets details:
  - Designed for use with 32x32 tiled maps.
  - Orientation: orthogonal
  - Shadowless PNG images use indexed color (smaller files).
  - Shadowed images & GIMP sources (.xcf) use RGB color (semi-transparent pixels).
Licensing:
  - Creative Commons Zero (CC0) (see: LICENSE.txt)
Attribution:
  Created by Hyptosis & mold
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81798
  - See also: sources.md
Notes:
  - Up to this point, all included works are licensed under CC0. The
    Authors do not require attribution. But their names are included
    for reference for any that would like to credit them. It is my
    intention to add more works from multiple sources. So attribution
    requirements will likely change with future edits.
