### Statues Collection Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top;">
      ![Bust](preview.png)
    </td>
    <td style="border: 0px;">
      ![Attribution](attribution.png)
    </td>
  </tr>
</table>

[OpenGameArt.org submission](https://opengameart.org/node/81798)

By [Hyptosis](https://opengameart.org/user/2937):
- bust & fountain from [Mage City Arcanos](https://opengameart.org/node/11192) (CC0)

By [Hyptosis](https://opengameart.org/user/2937) & [mold](https://opengameart.org/user/12427):
- child praying (CC0)
