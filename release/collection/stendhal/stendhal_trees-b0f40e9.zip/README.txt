Name:
  Stendhal Trees
Git commit:
  b0f40e9
Description:
  Original trees tilesets created for Stendhal.
Tileset details:
  - Created for use with 32x32 tiled maps.
  - Orientation: orthogonal
  - PNG images & GIMP source files (.xcf) use RGB color (more than 256 colors).
Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 or later (see: LICENSE.txt)
Copyright/Attribution:
  Copyright � 2017 Kimmo Rundelin
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81447
