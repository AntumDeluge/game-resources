Name:
  Stendhal Dragons
Git commit:
  3a64993
Description:
  Original dragon sprites created for Stendhal.
Sprite details:
  - Orientation: orthogonal (N/E/S/W)
  - Dimensions: 96x128
  - Animation:
    - idle (center frames)
    - walking: 12 frames (3 per direction)
    - Animated preview @ 150ms delay.
  - PNG images & GIMP sources (.xcf) use RGB color (more than 256 colors).
Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 or later (see: LICENSE.txt)
Copyright/Attribution:
  Copyright © 2017-2018 Kimmo Rundelin
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81282
  - See also: sources.md
