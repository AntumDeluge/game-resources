Name:
  Stendhal Dragons
Git commit:
  3c493b0-1
Description:
  Original dragon sprites created for Stendhal.
Sprite details:
  - Dimensions: 96x128
  - Orientation: N/S/E/W
  - Animation: 3 frames per direction
  - PNG images & GIMP source files (.xcf) use RGB color (more than 256 colors).
Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 or later (see: LICENSE.txt)
Copyright/Attribution:
  Copyright � 2017 Kimmo Rundelin
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81282
