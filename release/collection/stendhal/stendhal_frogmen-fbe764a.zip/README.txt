Name:
  Stendhal Frogmen
Git commit:
  fbe764a
Description:
  Original frogmen sprites created for Stendhal by Kimmo Rundelin (kiheru).
Sprite details:
  - Dimensions: 48x64
  - Orientation: orthogonal (N/S/E/W)
  - Animation: 3 frames per direction
  - PNG images use indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 or later (see: LICENSE.txt)
Copyright/Attribution:
  Copyright � 2014-2018 Kimmo Rundelin
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/82080
