Name:
  Cabbit Collection
Version:
  0.2
Description:
  A collection of sprites created by Svetlana Kushnariova (Cabbit)
  &/or diamonddmgirl.
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE-CC-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 4.0 (not included)
Attribution:
  Svetlana Kushnariova (Cabbit)
  diamonddmgirl
Links:
  - OpenGameArt.org page: https://opengameart.org/node/79804
  - For links to Cabbit's & diamonddmgirl's subbmissions, see "sources.md" file.
