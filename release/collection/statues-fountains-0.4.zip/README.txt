Name:
  Statues & Fountains Collection
Version:
  0.4
Description:
  A collection of statues & fountains tilesets for potential use
  as drop-in replacements or new additions in Stendhal.
Tilesets details:
  - Designed for use with 32x32 tiled maps.
  - Orientation: orthogonal
  - Shadowless PNG images use indexed color (smaller files).
  - Shadowed images & GIMP sources (.xcf) use RGB color (semi-transparent pixels).
Licensing (see "sources.md" for individual works' licensing):
  - Creative Commons Attribution (CC BY) version 3.0 (see: LICENSE-CC-BY-3.0.txt)
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 (see: LICENSE-CC-BY-SA-3.0.txt)
  - Creative Commons Zero (CC0) (see: LICENSE-CC0.txt)
  - GNU General Public License (GPL) version 3.0 (see: LICENSE-GPL-3.0.txt)
Attribution:
  Created by Daniel Cook, Wolthera van H�vell tot Westerflier (TheraHedwig), Hyptosis, mold, & Zachariah Husiar (Zabin)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81798
  - See also: sources.md
Notes:
  - IMPORTANT:
    - Up to this point, included works by Hyptosis, mold, & Zabin
      are licensed under CC0. They do not require attribution, but
      their names are included for reference for any that would
      like to credit them.
    - Attribution & licensing requirements may change with future
      edits & additions.
