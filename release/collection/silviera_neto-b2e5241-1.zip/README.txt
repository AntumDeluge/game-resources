silviera_neto collection b2e5241-1
Description:
  Sprites & tilesets created by Silviera Neto for OpenPixels project.
Licensing: Creative Commons Attribution-ShareAlike (CC BY-SA) version 4.0 (see: LICENSE.txt)
Links:
- OpenPixels GitHub: https://github.com/silveira/openpixels
