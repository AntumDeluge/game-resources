### Statues Collection Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top;">
      ![Bust](preview.png)
    </td>
    <td style="border: 0px;">
      ![Attribution](attribution.png)
    </td>
  </tr>
</table>

[OpenGameArt.org submission](https://opengameart.org/node/81798)

By [Daniel Cook](https://plus.google.com/+DanielCookGameDesign):
- stone armor
  - Sources:
    - [lostgarden.com](http://www.lostgarden.com/2006/07/more-free-game-graphics.html)
    - [2d Lost Garden Zelda style tiles resized to 32x32 with additions](https://opengameart.org/node/11758) (CC BY 3.0)

By [Hyptosis](https://opengameart.org/user/2937):
- bust & fountain from [Mage City Arcanos](https://opengameart.org/node/11192) (CC0)

By [Hyptosis](https://opengameart.org/user/2937) & [mold](https://opengameart.org/user/12427):
- child praying (CC0) (based on [CC0 image](https://www.publicdomainpictures.net/view-image.php?image=191696&picture=statue-of-praying-boy))
- wolf (CC0) (based on [CC0 image](https://pixabay.com/en/wolf-photo-manipulation-white-png-2104703/))
