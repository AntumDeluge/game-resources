Name:
  LPC Bazaar Rework
Version:
  1.0
Description:
  Reworked versions of LPC bazaar tilesets for use in Stendhal.
Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 or later (see: LICENSE-CC-BY-SA-3.0.txt)
  - GNU General Public License (GPL) version 3.0 or later (see: LICENSE-GPL-3.0.txt)
Attribution:
  Daniel Eddeland (daneeklu)
  Zachariah Husiar (Zabin)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81369
  - RPG Tiles: Cobble stone paths & town objects: https://opengameart.org/node/14914
  - [LPC] Farming tilesets, magic animations and UI elements: https://opengameart.org/node/11117
  - LPC Submissions Merged: https://opengameart.org/node/79256
Notes:
  The bottles were taken from the LPC Submissions Merged set. But, I am unsure who to credit
  as the original author. I will try to figure this out & update the package & attributions.
