### LPC Wooden Bridge Rework Sources

![Preview](preview.png)

[OpenGameArt.org submission](https://opengameart.org/node/81762)

By [Xenodora](https://opengameart.org/user/5683):
- [LPC style wood bridges and steel flooring](https://opengameart.org/node/15135) (CC BY-SA 3.0 / GPL 2.0+)
