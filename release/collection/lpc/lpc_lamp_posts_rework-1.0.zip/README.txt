Name:
  LPC Lamp Posts Rework
Version:
  1.0
Description:
  Reworked versions of [LPC] Street Lamp by Curt & Sharm, & Lamp
  from [LPC] Misc by Sharm & William.Thompsonj for Stendhal.
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 or later (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 or later (see: LICENSE-CC-BY-3.0.txt)
  - GNU General Public License (GPL) version 2.0 or later (see: LICENSE-GPL-2.0.txt & LICENSE-GPL-3.0.txt)
Copyright/Attribution:
  Created by Curt, Sharm, William.Thompsonj, & mold
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81455
  - For links to source submissions, see "sources.md" file.
Notes:
  Animated preview by mold.
