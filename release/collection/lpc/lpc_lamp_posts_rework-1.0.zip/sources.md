### LPC Lamp Posts Rework Sources

![Preview](preview.png)

[OpenGameArt.org submission](https://opengameart.org/node/81455)

By [Curt](https://opengameart.org/user/6231), [Lanea Zimmerman (Sharm)](https://opengameart.org/user/1727), & [Hyptosis](https://opengameart.org/user/2937):
- [[LPC] Street Lamp](https://opengameart.org/node/20039)

By [Lanea Zimmerman (Sharm)](https://opengameart.org/user/1727) & [William Thompson](https://opengameart.org/user/7593) (contributor):
- [[LPC] Misc](https://opengameart.org/node/20941)

Lamp 2 & U-shaped crossbar edited by [mold](https://opengameart.org/user/12427)
