**LPC Graves Sources**

By Barbara Rivera:
- [Concept Art for LPC Entry](https://opengameart.org/content/concept-art-for-lpc-entry)

By Casper Nilsson:
- [LPC C.Nilsson](https://opengameart.org/content/lpc-cnilsson)

By Carlo Enrico Victoria (Nemisys) & Tuomo Untinen (Reemax):
- [[LPC] Signposts, graves, line cloths and scare crow](https://opengameart.org/node/31884) (CC BY-SA / GPL)
- [LPC Sign Post](https://opengameart.org/node/24406) (CC BY-SA / GPL)

By Casper Nilsson, Barbara Rivera, & ak-blanc:
- [[LPC] Misc tile atlas](https://opengameart.org/node/49103)

Unknown:
- [LPC Submissions Merged](https://opengameart.org/node/79256)
