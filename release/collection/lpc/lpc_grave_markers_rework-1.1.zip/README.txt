Name:
  LPC Grave Markers Rework
Version:
  1.1
Description:
  Some LPC grave markers merged into a single set & reworked
  for use in Stendhal.
Licensing:
  - Creative Commons Attribution Share-Alike (CC BY-SA) version 3.0 or later
  - GNU General Public License (GPL) version 3.0 or later
Copyright/Attribution:
  By Barbara Rivera, Casper Nilsson, Carlo Enrico Victoria, Tuomo Untinen,
  & ak-blanc
Links/Sources:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81422
  - LPC art entries: https://opengameart.org/lpc-art-entries
Notes:
  I am unsure of the original author from the LPC Submissions Merged tileset.
  I will try to figure it out & update attributions.
