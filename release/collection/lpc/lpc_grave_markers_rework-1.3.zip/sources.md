### LPC Grave Markers Rework Sources

![Preview](preview.png)

[OpenGameArt.org submission](https://opengameart.org/node/81422)

By Barbara Rivera:
- [Concept Art for LPC Entry](https://opengameart.org/content/concept-art-for-lpc-entry) (CC BY-SA 3.0 / GPL 3.0)

By [Casper Nilsson](https://opengameart.org/user/2664):
- [LPC C.Nilsson](https://opengameart.org/content/lpc-cnilsson) (CC BY-SA 3.0 / GPL 3.0)

By [Carlo Enrico Victoria (Nemisys)](https://opengameart.org/user/14583) & [Tuomo Untinen (Reemax)](https://opengameart.org/user/5257):
- [[LPC] Signposts, graves, line cloths and scare crow](https://opengameart.org/node/31884) (CC BY-SA 3.0 / GPL 3.0)
- [LPC Sign Post](https://opengameart.org/node/24406) (OGA BY 3.0 / CC BY 3.0 / CC BY-SA 3.0 / GPL 3.0)

By [Casper Nilsson](https://opengameart.org/user/2664), Barbara Rivera, & [ak-blanc](https://opengameart.org/user/27293):
- [[LPC] Misc tile atlas](https://opengameart.org/node/49103) (CC BY-SA 3.0 / GPL 3.0)

By [Johann C](https://opengameart.org/user/1886):
- [[LPC] A shoot'em up complete graphic kit](https://opengameart.org/node/11079) (CC BY-SA 3.0 / GPL 3.0)
