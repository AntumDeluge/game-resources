Name:
  Anti-Poison Rings
Version:
  1.1
Description:
  Anti-poison ring equipment icons created for Stendhal. Currently
  there are three rings: medicinal (lavender), anti-venom (green),
  & anti-toxin (red).
Details:
  - Dimensions: 32x32
  - PNG images optimized with indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 or later (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 or later (see: LICENSE-CC-BY-[3.0/4.0].txt)
Copyright/Attribution:
  Created by Jordan Irwin (AntumDeluge)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/20712
