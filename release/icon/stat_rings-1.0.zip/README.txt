Name:
  Stat Rings
Version:
  1.0
Description:
  Just some ring icons I felt like creating. Based on my anti-poison
  rings. Currently there are two rings: atk (sword) & def (shield).
Details:
  - Dimensions: 32x32
  - PNG images optimized with indexed color (smaller files).
  - GIMP sources (.xcf) use RGB color.
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 or later (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 or later (see: LICENSE-CC-BY-[3.0/4.0].txt)
Copyright/Attribution:
  Created by Jordan Irwin (AntumDeluge)
Links:
  - OpenGameArt.org submission: https://opengameart.org/node/88263
