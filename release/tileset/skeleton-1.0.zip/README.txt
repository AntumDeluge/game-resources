skeleton v1.0
Created by RedVoxel: https://red-voxel.itch.io/
Licensing:
- Creative Commons Attribution (CC BY) version 3.0 (see LICENSE.txt)
- Some tiles reworked by Jordan Irwin (AntumDeluge)
  - These changes are licensed under CC0 so no additional attribution
    is required other than to original author, & entire tileset can
    be redistributed under original license.
Links:
- OpenGameArt.org: https://opengameart.org/node/79009
- OpenGameArt.org (Original): https://opengameart.org/node/77815
