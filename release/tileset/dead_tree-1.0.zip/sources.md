### Dead Tree (Yar's Tree Rework) Sources

![Preview](PNG/32x32/dead_tree-001.png)

[OpenGameArt.org submission](https://opengameart.org/node/81764)

By [Yar](https://opengameart.org/user/226):
- [Isometric 64x64 Outside Tileset](https://opengameart.org/node/3012) (CC BY 3.0)
