### Christmas Tree Tileset Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
  </tr>
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/89022)

#### Source Assets:
---

By b_o:
- [Pine Tree Tiles](https://opengameart.org/node/43645) (CC BY-SA 3.0 / GPL 2.0)

By [bleutailfly](https://stendhalgame.org/character/bleutailfly.html):
- [Christmas Tree](https://postimg.cc/rdrcnB6G) (CC BY-SA 3.0+)
