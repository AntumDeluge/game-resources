rowboat v1.0
Description:
  Recolored versions of Daniel Eddeland's (daneeklu) LPC row boat
  (https://opengameart.org/node/11117). Created by Daniel Eddeland.
Licensing:
- Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 (see LICENSE.txt).
- This work may also be redistributed under the GNU General Public License (GPL)
  version 3.0, according to the original author. Text for the GPL is not included.
OpenGameArt.org page: https://opengameart.org/node/79264
