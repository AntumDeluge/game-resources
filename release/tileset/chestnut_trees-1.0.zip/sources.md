### Chestnut Trees (Yar's Tree Rework) Sources

![Preview](PNG/32x32/chestnut-001.png)

[OpenGameArt.org submission](https://opengameart.org/node/81685)

By [Yar](https://opengameart.org/user/226):
- [Isometric 64x64 Outside Tileset](https://opengameart.org/node/3012) (CC BY 3.0)
