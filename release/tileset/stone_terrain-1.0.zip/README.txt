Name:
  stone_terrain
Version:
  1.0
Description:
  Stone terrain tileset created for Stendhal by Jordan Irwin
  (AntumDeluge).
Licensing: Can be redistributed under any of the following:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 or later
    (see: LICENSE.txt)
  - Creative Commons Attribution (CC BY) version 3.0 or later
    (text not included)
Notes:
  - The stone_ground tilesets are licensed under CC0 (public
    domain) (text not included).
Links:
  - OpenGameArt.org page: https://opengameart.org/node/79141
  - Stendhal: https://stendhalgame.org/
  - Public Domain Tiles: https://moosader.deviantart.com/art/Public-Domain-Tiles-210769545
