### Wooden Benches Tilesets Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Preview1](PNG/32x32/bench-wood.png)
    </td>
    <td style="border: 0px; vertical-align: top; text-align: center;">
    ![Preview2](PNG/32x32/bench-backless-white.png)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/79117)

By [Hyptosis](https://opengameart.org/user/2937):
- [Mage City Arcanos](https://opengameart.org/node/11192) (CC0)
