tent v0.2
Based on "Tent" by xhunterko: https://opengameart.org/node/55237
Reworked for Stendhal by Jordan Irwin (AntumDeluge)
Licensing:
  Only license text for Creative Commons Attribution (CC BY) version 3.0
  is included with this release (see: LICENSE.txt). But this work may also
  be released/redistributed under the following licenses according to the
  original author:
  - OpenGameArt Attribution (OGA BY) version 3.0
  - GNU General Public License (GPL) version 2.0 or version 3.0
