### Bed Tilesets Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Preview](preview.png)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/88265)

#### Source Assets:
---

By [bleutailfly](https://stendhalgame.org/character/bleutailfly.html):
- [original bed](https://github.com/arianne/stendhal/blob/dcd95d7984106c3104262dc0d56d9b127c878850/tiled/tileset/item/furniture/bed/large_front_on_darker.png) (CC BY-SA 3.0/4.0)

By Anonymous:
- [Pink Rose](https://openclipart.org/detail/23911) (CC0)
