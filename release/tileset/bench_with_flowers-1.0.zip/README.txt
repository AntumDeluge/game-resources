Name:
  Bench with Flowers
Version:
  1.0
Description:
  A bench with flowers tileset created for Stendhal.
Tileset details:
  - Designed for use with 32x32 tiled maps.
  - Orientation: orthogonal
  - Dimensions: 96x64
  - PNG images use indexed color (smaller files).
  - GIMP sources (.xcf) use RGB (sRGB/RGBA) color.
Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) version 3.0 (see: LICENSE-CC-BY-SA-3.0.txt)
  - GNU General Public License (GPL) version 3.0 (see: LICENSE-GPL-3.0.txt)
Copyright/Attribution:
  Created by:
  - Lanea Zimmerman (Sharm)
  - bluecarrot16 (https://opengameart.org/node/80124)
  - Guido Bos
  - Jetrel
  - Hyptosis
  - Jordan Irwin (AntumDeluge)
Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/81665
  - See also: sources.md
Notes:
  - Up to this point, works by Jetrel, Hyptosis, & Jordan Irwin are
    licensed under CC0. Attribution is not required but included in
    the Copyright/Attribution section. Attribution requirements may
    change with future edits.
