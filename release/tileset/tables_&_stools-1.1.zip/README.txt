tables_&_stools v1.1
Created by Jordan Irwin (AntumDeluge)
Description:
- Round and rectangular white tables & stools tileset.
- Designed for 32x32 pixel graphics.
- Originally created for Stendhal: https://stendhalgame.org/
Licensing:
- OpenGameArt.org Attribution (OGA BY) version 3.0 or later (see LICENSE-OGA_BY-3.0.txt)
- Creative Commons Attribution (CC BY) version 3.0 or later (see LICENSE-CC_BY-3.0.txt)
OpenGameArt.org page: https://opengameart.org/node/20715
