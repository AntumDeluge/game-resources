rotating_orbs v0.1
Based on Shiny Orbs 64x64 by Robert C. (Mumu): https://opengameart.org/node/12771
Reworked by Jordan Irwin (AntumDeluge)
Licensing: Creative Commons Zero (CC0) version 1.0 (see LICENSE.txt)
- Attribution not required, but always appreciated.
