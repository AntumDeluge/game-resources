### Crystals Tilesets Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top;">
      ![Preview](preview.png)
    </td>
  </tr>
</table>

[OpenGameArt.org submission](https://opengameart.org/node/79572)

By [Chris Fiedler (Chrisdesign)](https://chrisdesign.wordpress.com/) & [Iwan Gabovitch (qubodup)](https://opengameart.org/user/6):
- [Minerals](https://openclipart.org/detail/173471) (CC0)

By [MrSmiles](https://openclipart.org/user-detail/MrSmiles):
- [Purple Amethyst](https://openclipart.org/detail/122773) (CC0)
